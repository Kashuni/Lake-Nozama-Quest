


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kashuni
 */

import java.util.Arrays;

public class SuperWarrior extends Warrior{
    
    public SuperWarrior(int x, int y, String name){
        super(x,y,name);
    }
    
    private int[] checkLotus(int[] location){ 
        int x = location[0];
        int y = location[1];
        int[] newLocation = new int[2];
        if (Grid.getOccupant(x-1, y) == Grid.inhabitantTypes.LOTUS){
            newLocation[0] = x-1;
            newLocation[1] = y;
        } else if (Grid.getOccupant(x+1, y) == Grid.inhabitantTypes.LOTUS){
            //Grid.getOccupant(5, 5)==Grid.inhabitantTypes.TREASURE;
            newLocation[0] = x+1;
            newLocation[1] = y;    
        } else if (Grid.getOccupant(x, y-1) == Grid.inhabitantTypes.LOTUS){
            newLocation[0] = x;
            newLocation[1] = y-1;
        } else if (((Grid.getOccupant(x, y+1)).compareTo(Grid.inhabitantTypes.LOTUS))==0){
            newLocation[0] = x;
            newLocation[1] = y+1;
        } else{
            newLocation = location;
        }
        return newLocation;
    }
    
    private void moveToNewLocation(int[] newLocation){
        X = newLocation[0];
        Y = newLocation[1];
    }
    
    @Override
    public void moveWarrior(){
        if (getCanSwim() == true){
            int[] coordinates = new int[2];
            coordinates[0] = getX();
            coordinates[1] = getY();
            int[] newLocation = checkLotus(coordinates);
            if (!(Arrays.equals(newLocation, coordinates))){
                moveToNewLocation(newLocation);
            } else {
                super.moveWarrior();
            }
        }
    }
}
