/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kashuni
 */
public class NormalWarrior extends Warrior {
    
    public NormalWarrior(int x, int y, String name){
        super(x,y,name);
    }
}    