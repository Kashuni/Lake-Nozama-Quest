

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kashuni
 */
public abstract class Warrior extends GameObject implements Runnable{
    
    private static int noOfWarriors = 0;
    private boolean swimfins;
    private boolean immortal;
    private boolean killed;
    private boolean canSwim;
    private final long startTime;
    private long endTime;
    private final Object lock;

    public Warrior(int X, int Y, String name) {
        super(X, Y, name);
        swimfins=true;
        immortal=false;
        killed=false;
        canSwim=true;
        noOfWarriors++;
        startTime = System.currentTimeMillis();
        lock = new Object();
    }
    
    public static int getNoOfWarriors(){
        return noOfWarriors;
    }

    public boolean getFins() {
        return swimfins;
    }

    public boolean getImmortal() {
        return immortal;
    }

    public boolean getKilled() {
        return killed;
    }
    
    public boolean getCanSwim() {
        return canSwim;
    }

    public void setStolenFins() {
        System.out.println("Oops! The swimfins of "+getName()+"got stolen!!");
        swimfins = false;
        canSwim = false;
    }

    public void setImmortal() {
        if (getImmortal() == false) {
            System.out.println("Superb! "+getName()+" is now immortal!!");
            immortal = true;
        } else {}
    }
    
    public void pluckLotus(MagicLotus m){
            m.setPlucked(this);
    }

    public void setKilled() {
        if (getImmortal() == false){
            System.out.println("Oops! "+getName()+" got killed!!");
            killed = true;
            canSwim = false;
        } else {}
    }

    protected void moveXright() {
        if (checkWarriorInLocation(X+1,Y) == false){
            X++;
            System.out.println(getName()+" moved to ("+X+","+Y+")");       
            }
    }

    protected void moveXleft() {
        if (checkWarriorInLocation(X-1,Y) == false){
            X--;            
            System.out.println(getName()+" moved to ("+X+","+Y+")");
        }    
    }

    protected void moveYup() {
        if (checkWarriorInLocation(X,Y+1) == false){
            Y++;            
            System.out.println(getName()+" moved to ("+X+","+Y+")");
        }
    }

    protected void moveYdown() {
        if (checkWarriorInLocation(X,Y-1) == false){
            Y--;            
            System.out.println(getName()+" moved to ("+X+","+Y+")");
        }
    }
    
    private static boolean checkWarriorInLocation(int x, int y){
        return ((Grid.getOccupant(x, y) == Grid.inhabitantTypes.NORMALWARRIOR) ||
                (Grid.getOccupant(x, y) == Grid.inhabitantTypes.SUPERWARRIOR));
    }
    
    public void notifyTreasure(){
        
    }
    
    public void moveWarrior(){
        synchronized(lock){
            while (!((getX()==5) && (getY()==5))){
                int x = getX();
                int y = getY();
                if ((((5-x)>=0 && ((5-y)>=0))) && ((5-x)>=(5-y))){
                    moveXright();

                } else if ((((5-x)>=0 && ((5-y)>=0))) && ((5-x)<(5-y))){
                    moveYup();

                } else if ((((5-x)<0 && ((5-y)>=0))) && ((x-5)>=(5-y))){
                    moveXleft();

                } else if ((((5-x)<0 && ((5-y)>=0))) && ((x-5)<(5-y))){
                    moveYup();

                } else if ((((5-x)>=0 && ((5-y)<0))) && ((5-x)>=(y-5))){
                    moveXright();

                } else if ((((5-x)>=0 && ((5-y)<0))) && ((5-x)<(y-5))){
                    moveYdown();

                } else if ((((5-x)<0 && ((5-y)<0))) && ((x-5)>=(y-5))){
                    moveXleft();

                } else if ((((5-x)<0 && ((5-y)<0))) && ((x-5)<(y-5))){
                    moveYdown();

                } else{}
                try{
                    Thread.sleep(1000);
                } catch (InterruptedException e){
                }
            }
        endTime = System.currentTimeMillis();
        
        }
    }
    
    @Override
    public void run(){
        if (getFins() && getCanSwim() && (!getKilled())){
            moveWarrior();
        }
    }
}